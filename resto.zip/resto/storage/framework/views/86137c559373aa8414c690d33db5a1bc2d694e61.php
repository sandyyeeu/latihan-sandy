<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Pesan Makanan</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('daftarTransaksi')); ?>">Pesan Makanan</a></li>
                        <li class="breadcrumb-item active">Pesan Makanan</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
<?php $__env->startSection('addCss'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addJavascript'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script>
        $(function() {
            $("#data-table").DataTable()
        })
    </script>

    <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>

    <script>
        confirmDelete = function(button) {
            var url = $(button).data('url');
            swal({
                'title': 'Konfirmasi Hapus',
                'text': 'Apakah Kamu Yakin Ingin Menghapus Data Ini?',
                'dangerMode': true,
                'buttons': true
            }).then(function(value) {
                if (value) {
                    window.location = url;
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>
<!-- Main content -->
<div class="content">
    <div class="container-fluid">

        <div class="card">
            <div class="card-header text-right">
                <a href="<?php echo e(route('createTransaksi')); ?>" class="btn btn-success" role="button">Tambah Pesanan
                    <i class="bi bi-cart-check"></i>
                </a>
            </div>
            <div class="card-body p-0">
                <table class="table table-bordered mb-0" id="data-table">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama Pelanggan</th>
                            <th>Nama Barang</th>
                            <th>total</th>
                            <th>Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($loop->index + 1); ?></td>
                                <td> <?php echo e($transaksi->pelanggan? $transaksi->pelanggan->nama: '-'); ?></td>
                                <td> <?php echo e($transaksi->barang? $transaksi->barang->barang: '-'); ?></td>
                                <td> <?php echo e($transaksi->total); ?></td>
                                <td> <?php echo e($transaksi->tgl); ?></td>
                                <td>
                                    <a href="<?php echo e(route('editTransaksi', ['id' => $transaksi->id])); ?>"
                                        class="btn btn-danger btn-sm" role="button">Edit
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a onclick="confirmDelete(this)"
                                        data-url="<?php echo e(route('deleteTransaksi', ['id' => $transaksi->id])); ?>"
                                        class="btn btn-warning btn-sm" role="button">Hapus
                                        <i class="bi bi-trash-fill"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>

    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resto\resources\views/transaksi/index.blade.php ENDPATH**/ ?>