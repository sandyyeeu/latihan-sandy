<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Dashboard</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
					<li class="breadcrumb-item active">Dashboard</li>
				</ol>
			</div><!-- /.col -->
		</div>
        <!-- /.row -->
        <div class="col1-x1-3 col-md-3">

            <div class="card bg-info text-white mb-4">
                <div class="card-body">Menu Makanan<i class="bi bi-clipboard2-check"></i>

                    <h4 class="mb-0">
                        <?php echo e($barang); ?>

                    </h4>
                </div>

                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?php echo e(route('daftarBarang')); ?>">Lihat Menu
                    </a>
                    <div class="small text-white"><i class="fas fa-angel-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col1-x1-3 col-md-3">

            <div class="card bg-success text-white mb-4">
                <div class="card-body">Pelanggan   <i class="bi bi-journal-text"></i>

                    <h4 class="mb-0">
                        <?php echo e($pelanggan); ?>

                    </h4>
                </div>

                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?php echo e(route('daftarPelanggan')); ?>">Lihat Pelanggan
                    </a>
                    <div class="small text-white"><i class="fas fa-angel-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col1-x1-3 col-md-3">

            <div class="card bg-secondary text-white mb-4">
                <div class="card-body">Pembayaran

                    <h4 class="mb-0">
                        <?php echo e($transaksi); ?>

                    </h4>
                </div>

                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="<?php echo e(route('daftarTransaksi')); ?>">View Details</a>
                    <div class="small text-white"><i class="fas fa-angel-right"></i></div>
                </div>
            </div>
        </div>
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class="content">
	<div class="container-fluid">

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resto\resources\views/dashboard.blade.php ENDPATH**/ ?>