<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Data Pelanggan</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('daftarPelanggan')); ?>">Data Pelanggan</a></li>
					<li class="breadcrumb-item active">Data</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<?php $__env->startSection('addCss'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addJavascript'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script>
        $(function() {
            $("#data-table").DataTable()
        })
    </script>

    <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>

    <script>
        confirmDelete = function(button) {
            var url = $(button).data('url');
            swal({
                'title': 'Konfirmasi Hapus',
                'text': 'Apakah Kamu Yakin Ingin Menghapus Data Ini?',
                'dangerMode': true,
                'buttons': true
            }).then(function(value) {
                if (value) {
                    window.location = url;
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<!-- Main content -->
<div class="content">
	<div class="container-fluid">

        <div class ="card" >
            <div class = "card-header text-right">
                <a href="<?php echo e(route('createPelanggan')); ?>" class= 'btn btn-success' role="button"> Tambah
                    <i class="bi bi-bag-plus-fill"></i>
                </a>
            </div>
            <div class="card-bordy p-0">
            </div>
        </div>
        <div class= "card-body p-0">
            <table class ="table table-striped table-bordered  m-0 " id="data-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No Telpon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>

                        <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($pelanggan->nama); ?></td>
                            <td><?php echo e($pelanggan->alamat); ?></td>
                            <td><?php echo e($pelanggan->nohp); ?></td>
                            <td>
                                <a href="<?php echo e(route('editPelanggan',['id' =>$pelanggan->id])); ?>" class = 'btn btn-warning' role="button">Edit
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <a onclick="confirmDelete(this)"data-url="<?php echo e(route('deletePelanggan',['id' => $pelanggan])); ?>" class = 'btn btn-danger' role ="button">Hapus
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>

                </tbody>
            </table>
        </div>
    </div>
</div>



                </tbody>
            </table>
        </div>


<div class="content">
	<div class="container-fluid">

		

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resto\resources\views/pelanggan/index.blade.php ENDPATH**/ ?>