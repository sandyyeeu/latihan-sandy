<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Tambah Pesanan</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('daftarTransaksi')); ?>">Pesan Makanan</a></li>
					<li class="breadcrumb-item active">Tambah Pesanan</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('storeTransaksi')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="id_pelanggan">Nama Pelanggan</label>
                    <select class="form-control" name="id_pelanggan" id="id_pelanggan" required="required">
                        <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pelanggan->id); ?>"><?php echo e($pelanggan->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                        <label for="id_barang">Nama Makan</label>
                    <select class="form-control" name="id_barang" id="id_barang" required="required">
                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($barang->id); ?>"><?php echo e($barang->barang); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>


                    <div class="form-group">
                        <label for="total">Jumlah Pesanan</label>
                        <input type="text" name="total" id="total" class="form-control" required="required" placeholder="Masukan Jumlah Pesanan">
                    </div>

                    <div class="form-group">
                        <label for="tgl">Tanggal Pemesanan</label>
                        <input type="date" name="tgl" id="tgl" class="form-control" required="required" placeholder="Masukan Tanggal">
                    </div>



                    <div class="text-right">
                        <a href="<?php echo e(route('daftarTransaksi')); ?>" class="btn btn-dark" role="button">Batal</a>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>

<div class="content">
	<div class="container-fluid">
		

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resto\resources\views/transaksi/create.blade.php ENDPATH**/ ?>