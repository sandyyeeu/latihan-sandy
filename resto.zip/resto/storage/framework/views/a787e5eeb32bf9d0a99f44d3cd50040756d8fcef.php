<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Edit Data pelanggan</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('daftarPelanggan')); ?>">Data Pelanggan</a></li>
					<li class="breadcrumb-item active">Edit</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class= "card">
    <div class ="card-body">
        <form action="<?php echo e(route('updatePelanggan', ['id' => $pelanggan ->id])); ?>" method ="post">
            <?php echo csrf_field(); ?>
            <div class= "form-group">
                <label for="nama">Nama Anda</label>
                <input type="text" name="nama" id="nama" rows="2" class="form-control" required="required" value="<?php echo e($pelanggan->nama); ?>"placeholder="Masukan Menu">
            </div>

            <div class ="form-group">
                <label for="alamat">Edit Alamat</label>
                <input type="text" name="alamat" id="alamat" rows="2" class ="form-control" required="required" value="<?php echo e($pelanggan->alamat); ?>" placeholder="Masukan Menu">
            </div>

            <div class ="form-group">
                <label for="nohp">Edi No Telp</label>
                <input type="text" name="nohp" id="nohp" rows="2" class ="form-control" required="required"value="<?php echo e($pelanggan->nohp); ?>" placeholder="Masukan Harga">
            </div>
            <div class = "text-rigt">
                <a href="<?php echo e(route('daftarPelanggan')); ?>" class ="btn btn-dark" role="button">Batal
                    <i class="bi bi-x-square"></i>
                </a>
                <button type = "submit" class="btn btn-success">Simpan
                    <i class="bi bi-save2"></i> </button>
            </div>
        </form>
    </div>
</div>
<div class="content">
	<div class="container-fluid">

		

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resto\resources\views/pelanggan/edit.blade.php ENDPATH**/ ?>