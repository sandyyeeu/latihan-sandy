<?php

namespace App\Http\Controllers;
use App\Barang;
use App\Pelanggan;
use App\Transaksi;


use Illuminate\Http\Request;

use function Ramsey\Uuid\v1;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $barang = Barang::all()->count();
        $pelanggan = Pelanggan::all()->count();
        $transaksi = Transaksi::all()->count();

        return view('dashboard', compact('barang','pelanggan','transaksi'));
    }
}
