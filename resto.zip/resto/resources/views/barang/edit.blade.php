@extends('layouts.master')

@section('content')
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Edit Menu Makanan</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{route('daftarBarang')}}">Menu Makanan</a></li>
					<li class="breadcrumb-item active">Edit</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class= "card">
    <div class ="card-body">
        <form action="{{ route('updateBarang', ['id' => $barang->id]) }}" method ="post">
            @csrf
            <div class= "form-group">
                <label for="nama">Nama Anda</label>
                <input type="text" name="nama" id="nama" rows="2" class="form-control" required="required" value="{{ $barang->nama }}"placeholder="Masukan Menu">
            </div>

            <div class ="form-group">
                <label for="barang">Menu Hari Ini</label>
                <input type="text" name="barang" id="barang" rows="2" class ="form-control" required="required" value="{{ $barang->barang }}" placeholder="Masukan Menu">
            </div>

            <div class ="form-group">
                <label for="Harga">Harga Hari Ini</label>
                <input type="number" name="harga" id="harga" rows="2" class ="form-control" required="required"value="{{ $barang->harga }}" placeholder="Masukan Harga">
            </div>
            <div class = "text-rigt">
                <a href="{{ route('daftarBarang') }}" class ="btn btn-dark" role="button">Batal
                    <i class="bi bi-x-square"></i>
                </a>
                <button type = "submit" class="btn btn-success">Simpan
                    <i class="bi bi-save2"></i> </button>
            </div>
        </form>
    </div>
</div>
<div class="content">
	<div class="container-fluid">

		{{-- main content here --}}

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
@endsection
