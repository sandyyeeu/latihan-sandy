@extends('layouts.master')

@section('content')
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Tambah Pesanan</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{route('daftarTransaksi')}}">Pesan Makanan</a></li>
					<li class="breadcrumb-item active">Tambah Pesanan</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
        <div class="card">
            <div class="card-body">
                <form action="{{ route('storeTransaksi') }}" method="post">
                    @csrf

                    <div class="form-group">
                        <label for="id_pelanggan">Nama Pelanggan</label>
                    <select class="form-control" name="id_pelanggan" id="id_pelanggan" required="required">
                        @foreach($pelanggans as $pelanggan)
                            <option value="{{$pelanggan->id}}">{{ $pelanggan->nama }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                        <label for="id_barang">Nama Makan</label>
                    <select class="form-control" name="id_barang" id="id_barang" required="required">
                        @foreach($barangs as $barang)
                            <option value="{{$barang->id}}">{{ $barang->barang }}</option>
                        @endforeach
                    </select>
                </div>


                    <div class="form-group">
                        <label for="total">Jumlah Pesanan</label>
                        <input type="text" name="total" id="total" class="form-control" required="required" placeholder="Masukan Jumlah Pesanan">
                    </div>

                    <div class="form-group">
                        <label for="tgl">Tanggal Pemesanan</label>
                        <input type="date" name="tgl" id="tgl" class="form-control" required="required" placeholder="Masukan Tanggal">
                    </div>



                    <div class="text-right">
                        <a href="{{ route('daftarTransaksi') }}" class="btn btn-dark" role="button">Batal</a>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>

<div class="content">
	<div class="container-fluid">
		{{-- main content here --}}

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
@endsection
