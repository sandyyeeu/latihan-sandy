@extends('layouts.master')

@section('content')
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Edit Data pelanggan</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{route('daftarPelanggan')}}">Data Pelanggan</a></li>
					<li class="breadcrumb-item active">Edit</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class= "card">
    <div class ="card-body">
        <form action="{{ route('updatePelanggan', ['id' => $pelanggan ->id]) }}" method ="post">
            @csrf
            <div class= "form-group">
                <label for="nama">Nama Anda</label>
                <input type="text" name="nama" id="nama" rows="2" class="form-control" required="required" value="{{ $pelanggan->nama }}"placeholder="Masukan Menu">
            </div>

            <div class ="form-group">
                <label for="alamat">Edit Alamat</label>
                <input type="text" name="alamat" id="alamat" rows="2" class ="form-control" required="required" value="{{ $pelanggan->alamat}}" placeholder="Masukan Menu">
            </div>

            <div class ="form-group">
                <label for="nohp">Edi No Telp</label>
                <input type="text" name="nohp" id="nohp" rows="2" class ="form-control" required="required"value="{{ $pelanggan->nohp }}" placeholder="Masukan Harga">
            </div>
            <div class = "text-rigt">
                <a href="{{ route('daftarPelanggan') }}" class ="btn btn-dark" role="button">Batal
                    <i class="bi bi-x-square"></i>
                </a>
                <button type = "submit" class="btn btn-success">Simpan
                    <i class="bi bi-save2"></i> </button>
            </div>
        </form>
    </div>
</div>
<div class="content">
	<div class="container-fluid">

		{{-- main content here --}}

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
@endsection
