@extends('layouts.master')

@section('content')
<!-- Content Header (Page header) -->
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0 text-dark">Data Pelanggan</h1>
			</div><!-- /.col -->
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{route('daftarPelanggan')}}">Data Pelanggan</a></li>
					<li class="breadcrumb-item active">Data</li>
				</ol>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
@section('addCss')
    <link rel="stylesheet" href="{{ asset('css/dataTables.bootstrap4.min.css') }}">
@endsection

@section('addJavascript')
    <script src="{{ asset('js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('js/dataTables.bootstrap4.min.js') }}"></script>
    <script>
        $(function() {
            $("#data-table").DataTable()
        })
    </script>

    <script src="{{ asset('js/sweetalert.min.js') }}"></script>

    <script>
        confirmDelete = function(button) {
            var url = $(button).data('url');
            swal({
                'title': 'Konfirmasi Hapus',
                'text': 'Apakah Kamu Yakin Ingin Menghapus Data Ini?',
                'dangerMode': true,
                'buttons': true
            }).then(function(value) {
                if (value) {
                    window.location = url;
                }
            })
        }
    </script>
@endsection

<!-- Main content -->
<div class="content">
	<div class="container-fluid">

        <div class ="card" >
            <div class = "card-header text-right">
                <a href="{{ route('createPelanggan') }}" class= 'btn btn-success' role="button"> Tambah
                    <i class="bi bi-bag-plus-fill"></i>
                </a>
            </div>
            <div class="card-bordy p-0">
            </div>
        </div>
        <div class= "card-body p-0">
            <table class ="table table-striped table-bordered  m-0 " id="data-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No Telpon</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>

                        @foreach($pelanggans as $pelanggan)
                        <tr>
                            <td> {{ $loop->index + 1 }}</td>
                            <td>{{ $pelanggan->nama }}</td>
                            <td>{{ $pelanggan->alamat }}</td>
                            <td>{{ $pelanggan->nohp }}</td>
                            <td>
                                <a href="{{ route('editPelanggan',['id' =>$pelanggan->id]) }}" class = 'btn btn-warning' role="button">Edit
                                    <i class="bi bi-pencil-square"></i>
                                </a>
                                <a onclick="confirmDelete(this)"data-url="{{ route('deletePelanggan',['id' => $pelanggan]) }}" class = 'btn btn-danger' role ="button">Hapus
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                            @endforeach
                        </tr>

                </tbody>
            </table>
        </div>
    </div>
</div>



                </tbody>
            </table>
        </div>


<div class="content">
	<div class="container-fluid">

		{{-- main content here --}}

	</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
@endsection
